import React, { useState } from 'react';
import { Layout, Menu, Card, Row, Col, Statistic, Table, Badge, Typography, Avatar, Progress, Tag, Space, Button } from 'antd';
import { 
  DashboardOutlined, 
  UserOutlined, 
  ShoppingCartOutlined, 
  BarChartOutlined,
  SettingOutlined,
  BellOutlined,
  SearchOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined
} from '@ant-design/icons';
import ReactECharts from 'echarts-for-react';
import './App.css';

const { Header, Sider, Content } = Layout;
const { Title, Text } = Typography;

// Sample data for charts
const salesData = {
  title: { text: 'Sales Overview' },
  tooltip: { trigger: 'axis' },
  legend: { data: ['Sales', 'Profit'] },
  xAxis: { 
    type: 'category',
    data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  },
  yAxis: { type: 'value' },
  series: [
    {
      name: 'Sales',
      type: 'line',
      data: [120, 200, 150, 80, 70, 110, 130, 180, 160, 200, 190, 230],
      smooth: true,
      itemStyle: { color: '#1890ff' }
    },
    {
      name: 'Profit',
      type: 'line',
      data: [20, 50, 30, 40, 35, 55, 65, 80, 75, 90, 85, 100],
      smooth: true,
      itemStyle: { color: '#52c41a' }
    }
  ]
};

const pieData = {
  title: { text: 'Revenue Distribution', left: 'center' },
  tooltip: { trigger: 'item' },
  legend: { orient: 'vertical', left: 'left' },
  series: [
    {
      name: 'Revenue',
      type: 'pie',
      radius: '50%',
      data: [
        { value: 335, name: 'Product A' },
        { value: 310, name: 'Product B' },
        { value: 274, name: 'Product C' },
        { value: 235, name: 'Product D' },
        { value: 400, name: 'Product E' }
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }
  ]
};

const barData = {
  title: { text: 'Monthly Performance' },
  tooltip: { trigger: 'axis' },
  xAxis: {
    type: 'category',
    data: ['Q1', 'Q2', 'Q3', 'Q4']
  },
  yAxis: { type: 'value' },
  series: [
    {
      name: 'Performance',
      type: 'bar',
      data: [320, 432, 301, 534],
      itemStyle: { 
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: '#87d068' },
            { offset: 1, color: '#52c41a' }
          ]
        }
      }
    }
  ]
};

const areaData = {
  title: { text: 'User Activity' },
  tooltip: { trigger: 'axis' },
  xAxis: {
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  },
  yAxis: { type: 'value' },
  series: [
    {
      name: 'Active Users',
      type: 'line',
      data: [820, 932, 901, 934, 1290, 1330, 1320],
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(24, 144, 255, 0.6)' },
            { offset: 1, color: 'rgba(24, 144, 255, 0.1)' }
          ]
        }
      },
      itemStyle: { color: '#1890ff' }
    }
  ]
};

// Table data
const tableData = [
  {
    key: '1',
    name: 'John Brown',
    email: 'john@example.com',
    status: 'active',
    revenue: '$2,400',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=64&h=64&dpr=1'
  },
  {
    key: '2',
    name: 'Jim Green',
    email: 'jim@example.com',
    status: 'inactive',
    revenue: '$1,800',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=64&h=64&dpr=1'
  },
  {
    key: '3',
    name: 'Joe Black',
    email: 'joe@example.com',
    status: 'active',
    revenue: '$3,200',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=64&h=64&dpr=1'
  },
  {
    key: '4',
    name: 'Alice Smith',
    email: 'alice@example.com',
    status: 'pending',
    revenue: '$2,100',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=64&h=64&dpr=1'
  }
];

const tableColumns = [
  {
    title: 'User',
    dataIndex: 'name',
    key: 'name',
    render: (text: string, record: any) => (
      <Space>
        <Avatar src={record.avatar} />
        <div>
          <div className="font-medium">{text}</div>
          <div className="text-gray-500 text-sm">{record.email}</div>
        </div>
      </Space>
    ),
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    render: (status: string) => (
      <Badge 
        status={status === 'active' ? 'success' : status === 'pending' ? 'processing' : 'default'} 
        text={status.charAt(0).toUpperCase() + status.slice(1)}
      />
    ),
  },
  {
    title: 'Revenue',
    dataIndex: 'revenue',
    key: 'revenue',
    render: (revenue: string) => (
      <Text strong>{revenue}</Text>
    ),
  },
];

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [selectedKey, setSelectedKey] = useState('1');

  const menuItems = [
    {
      key: '1',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
    },
    {
      key: '2',
      icon: <UserOutlined />,
      label: 'Users',
    },
    {
      key: '3',
      icon: <ShoppingCartOutlined />,
      label: 'Orders',
    },
    {
      key: '4',
      icon: <BarChartOutlined />,
      label: 'Analytics',
    },
    {
      key: '5',
      icon: <SettingOutlined />,
      label: 'Settings',
    },
  ];

  return (
    <Layout className="min-h-screen">
      <Sider 
        trigger={null} 
        collapsible 
        collapsed={collapsed}
        className="bg-white shadow-lg"
        width={280}
      >
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DashboardOutlined className="text-white" />
            </div>
            {!collapsed && (
              <Title level={4} className="!mb-0 text-gray-800">
                Admin Panel
              </Title>
            )}
          </div>
        </div>
        <Menu
          theme="light"
          mode="inline"
          selectedKeys={[selectedKey]}
          onClick={({ key }) => setSelectedKey(key)}
          items={menuItems}
          className="border-0 py-4"
        />
      </Sider>
      
      <Layout>
        <Header className="bg-white shadow-sm px-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => setCollapsed(!collapsed)}
              className="text-gray-600"
            />
            <Title level={3} className="!mb-0 text-gray-800">
              Dashboard Overview
            </Title>
          </div>
          <div className="flex items-center space-x-4">
            <Button type="text" icon={<SearchOutlined />} />
            <Button type="text" icon={<BellOutlined />} />
            <Avatar src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&dpr=1" />
          </div>
        </Header>
        
        <Content className="p-6 bg-gray-50">
          {/* Statistics Cards */}
          <Row gutter={[24, 24]} className="mb-6">
            <Col xs={24} sm={12} lg={6}>
              <Card className="text-center shadow-sm hover:shadow-md transition-shadow">
                <Statistic
                  title="Total Revenue"
                  value={45231}
                  precision={2}
                  valueStyle={{ color: '#3f8600' }}
                  prefix={<ArrowUpOutlined />}
                  suffix="$"
                />
                <div className="text-sm text-gray-500 mt-2">+12% from last month</div>
              </Card>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Card className="text-center shadow-sm hover:shadow-md transition-shadow">
                <Statistic
                  title="Active Users"
                  value={1128}
                  valueStyle={{ color: '#1890ff' }}
                  prefix={<UserOutlined />}
                />
                <div className="text-sm text-gray-500 mt-2">+8% from last week</div>
              </Card>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Card className="text-center shadow-sm hover:shadow-md transition-shadow">
                <Statistic
                  title="Total Orders"
                  value={642}
                  valueStyle={{ color: '#722ed1' }}
                  prefix={<ShoppingCartOutlined />}
                />
                <div className="text-sm text-gray-500 mt-2">+15% from yesterday</div>
              </Card>
            </Col>
            <Col xs={24} sm={12} lg={6}>
              <Card className="text-center shadow-sm hover:shadow-md transition-shadow">
                <Statistic
                  title="Conversion Rate"
                  value={3.4}
                  precision={1}
                  valueStyle={{ color: '#cf1322' }}
                  prefix={<ArrowDownOutlined />}
                  suffix="%"
                />
                <div className="text-sm text-gray-500 mt-2">-2% from last month</div>
              </Card>
            </Col>
          </Row>

          {/* Charts Section */}
          <Row gutter={[24, 24]} className="mb-6">
            <Col xs={24} lg={16}>
              <Card title="Sales Overview" className="shadow-sm">
                <ReactECharts 
                  option={salesData} 
                  style={{ height: 400 }}
                  opts={{ renderer: 'svg' }}
                />
              </Card>
            </Col>
            <Col xs={24} lg={8}>
              <Card title="Revenue Distribution" className="shadow-sm">
                <ReactECharts 
                  option={pieData} 
                  style={{ height: 400 }}
                  opts={{ renderer: 'svg' }}
                />
              </Card>
            </Col>
          </Row>

          <Row gutter={[24, 24]} className="mb-6">
            <Col xs={24} lg={12}>
              <Card title="Quarterly Performance" className="shadow-sm">
                <ReactECharts 
                  option={barData} 
                  style={{ height: 300 }}
                  opts={{ renderer: 'svg' }}
                />
              </Card>
            </Col>
            <Col xs={24} lg={12}>
              <Card title="User Activity" className="shadow-sm">
                <ReactECharts 
                  option={areaData} 
                  style={{ height: 300 }}
                  opts={{ renderer: 'svg' }}
                />
              </Card>
            </Col>
          </Row>

          {/* Progress and Table Section */}
          <Row gutter={[24, 24]}>
            <Col xs={24} lg={8}>
              <Card title="Project Progress" className="shadow-sm">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <Text>Website Redesign</Text>
                      <Text>75%</Text>
                    </div>
                    <Progress percent={75} strokeColor="#52c41a" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <Text>Mobile App</Text>
                      <Text>45%</Text>
                    </div>
                    <Progress percent={45} strokeColor="#1890ff" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <Text>API Integration</Text>
                      <Text>90%</Text>
                    </div>
                    <Progress percent={90} strokeColor="#722ed1" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <Text>Database Migration</Text>
                      <Text>60%</Text>
                    </div>
                    <Progress percent={60} strokeColor="#fa8c16" />
                  </div>
                </div>
              </Card>
            </Col>
            <Col xs={24} lg={16}>
              <Card title="Recent Users" className="shadow-sm">
                <Table
                  dataSource={tableData}
                  columns={tableColumns}
                  pagination={false}
                  className="custom-table"
                />
              </Card>
            </Col>
          </Row>
        </Content>
      </Layout>
    </Layout>
  );
}

export default App;