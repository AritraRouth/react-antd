export interface User {
  key: string;
  name: string;
  email: string;
  status: 'active' | 'inactive' | 'pending';
  revenue: string;
  avatar: string;
}

export interface ChartData {
  title: string;
  data: number[];
  labels: string[];
  colors?: string[];
}

export interface StatisticData {
  title: string;
  value: number;
  trend: 'up' | 'down' | 'stable';
  change: string;
  icon: React.ReactNode;
}

export interface MenuItem {
  key: string;
  icon: React.ReactNode;
  label: string;
  path?: string;
}