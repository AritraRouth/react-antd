import React from 'react';
import { Card } from 'antd';
import ReactECharts from 'echarts-for-react';

interface ChartCardProps {
  title: string;
  option: any;
  height?: number;
  className?: string;
}

const ChartCard: React.FC<ChartCardProps> = ({
  title,
  option,
  height = 300,
  className = ''
}) => {
  return (
    <Card title={title} className={`shadow-sm ${className}`}>
      <ReactECharts
        option={option}
        style={{ height }}
        opts={{ renderer: 'svg' }}
      />
    </Card>
  );
};

export default ChartCard;