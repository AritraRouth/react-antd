import React from 'react';
import { Card, Statistic } from 'antd';
import { ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons';

interface StatCardProps {
  title: string;
  value: number;
  prefix?: React.ReactNode;
  suffix?: string;
  precision?: number;
  trend?: 'up' | 'down';
  trendValue?: string;
  color?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  prefix,
  suffix,
  precision = 0,
  trend,
  trendValue,
  color = '#1890ff'
}) => {
  const getTrendIcon = () => {
    if (trend === 'up') return <ArrowUpOutlined />;
    if (trend === 'down') return <ArrowDownOutlined />;
    return null;
  };

  const getTrendColor = () => {
    if (trend === 'up') return '#3f8600';
    if (trend === 'down') return '#cf1322';
    return color;
  };

  return (
    <Card className="text-center shadow-sm hover:shadow-md transition-shadow">
      <Statistic
        title={title}
        value={value}
        precision={precision}
        valueStyle={{ color: getTrendColor() }}
        prefix={prefix || getTrendIcon()}
        suffix={suffix}
      />
      {trendValue && (
        <div className="text-sm text-gray-500 mt-2">{trendValue}</div>
      )}
    </Card>
  );
};

export default StatCard;