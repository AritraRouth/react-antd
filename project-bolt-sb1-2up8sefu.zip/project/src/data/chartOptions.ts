export const salesChartOption = {
  title: { text: 'Sales Overview' },
  tooltip: { trigger: 'axis' },
  legend: { data: ['Sales', 'Profit'] },
  xAxis: { 
    type: 'category',
    data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  },
  yAxis: { type: 'value' },
  series: [
    {
      name: 'Sales',
      type: 'line',
      data: [120, 200, 150, 80, 70, 110, 130, 180, 160, 200, 190, 230],
      smooth: true,
      itemStyle: { color: '#1890ff' }
    },
    {
      name: 'Profit',
      type: 'line',
      data: [20, 50, 30, 40, 35, 55, 65, 80, 75, 90, 85, 100],
      smooth: true,
      itemStyle: { color: '#52c41a' }
    }
  ]
};

export const pieChartOption = {
  title: { text: 'Revenue Distribution', left: 'center' },
  tooltip: { trigger: 'item' },
  legend: { orient: 'vertical', left: 'left' },
  series: [
    {
      name: 'Revenue',
      type: 'pie',
      radius: '50%',
      data: [
        { value: 335, name: 'Product A' },
        { value: 310, name: 'Product B' },
        { value: 274, name: 'Product C' },
        { value: 235, name: 'Product D' },
        { value: 400, name: 'Product E' }
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }
  ]
};

export const barChartOption = {
  title: { text: 'Monthly Performance' },
  tooltip: { trigger: 'axis' },
  xAxis: {
    type: 'category',
    data: ['Q1', 'Q2', 'Q3', 'Q4']
  },
  yAxis: { type: 'value' },
  series: [
    {
      name: 'Performance',
      type: 'bar',
      data: [320, 432, 301, 534],
      itemStyle: { 
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: '#87d068' },
            { offset: 1, color: '#52c41a' }
          ]
        }
      }
    }
  ]
};

export const areaChartOption = {
  title: { text: 'User Activity' },
  tooltip: { trigger: 'axis' },
  xAxis: {
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  },
  yAxis: { type: 'value' },
  series: [
    {
      name: 'Active Users',
      type: 'line',
      data: [820, 932, 901, 934, 1290, 1330, 1320],
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(24, 144, 255, 0.6)' },
            { offset: 1, color: 'rgba(24, 144, 255, 0.1)' }
          ]
        }
      },
      itemStyle: { color: '#1890ff' }
    }
  ]
};

export const donutChartOption = {
  title: { text: 'Traffic Sources', left: 'center' },
  tooltip: { trigger: 'item' },
  legend: { orient: 'vertical', left: 'left' },
  series: [
    {
      name: 'Traffic',
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      label: { show: false },
      emphasis: { label: { show: true, fontSize: '14', fontWeight: 'bold' } },
      labelLine: { show: false },
      data: [
        { value: 1048, name: 'Search Engines' },
        { value: 735, name: 'Direct' },
        { value: 580, name: 'Social Media' },
        { value: 484, name: 'Email' },
        { value: 300, name: 'Referrals' }
      ]
    }
  ]
};

export const gaugeChartOption = {
  title: { text: 'Performance Score' },
  series: [
    {
      name: 'Score',
      type: 'gauge',
      progress: { show: true, width: 18 },
      axisLine: { lineStyle: { width: 18 } },
      axisTick: { show: false },
      splitLine: { length: 15 },
      axisLabel: { distance: 25, color: '#999', fontSize: 12 },
      anchor: { show: true, showAbove: true, size: 25 },
      title: { show: false },
      detail: {
        valueAnimation: true,
        fontSize: 30,
        offsetCenter: [0, '70%']
      },
      data: [{ value: 87, name: 'Score' }]
    }
  ]
};